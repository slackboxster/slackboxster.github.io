#!/usr/bin/env bash

# Write your log script here.
