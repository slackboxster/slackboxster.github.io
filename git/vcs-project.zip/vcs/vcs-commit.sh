#!/usr/bin/env bash

# Write your commit script here.
