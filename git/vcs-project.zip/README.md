Set your path to invoke the scripts with `. ./path.sh`

Run the tests with `make test`
