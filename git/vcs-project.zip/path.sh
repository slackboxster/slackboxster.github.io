#!/usr/bin/env bash

export PATH="$PATH:`pwd`/vcs"
